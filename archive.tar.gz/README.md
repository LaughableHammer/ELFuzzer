This folder is a possible example submission.

As a student **you can change any file in this directory except for run_fuzzer.sh**.

We will be providing the `run_fuzzer.sh` file.

You must supply a folder with at least a DockerFile that describes how to build/compile/run your fuzzer.

See the assignment spec for more details.
