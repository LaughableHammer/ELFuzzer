#include <stdio.h>

int main(void) {
    while(1 == 1) {
        printf("Hang in there buddy\n");
    }
    return 0;
}