from pathlib import Path
from io import StringIO # allows dealing with file-like objects in memory
import agnostic_mutator
import globalVar
import json, csv
from lxml import etree
from mutators.csv_mutator import csv_mutate
from mutators.json_mutator import json_mutate
from mutators.xml_mutator import xml_mutate
from flatten_dict import flatten, unflatten
from mutators.jpg_mutator import jpg_mutate
from mutators.elf_mutator import elf_mutate
from mutators.pdf_mutator import pdf_mutate
from colours import Colours
import random

def decode_bytes(b: bytes) -> str:
    try:
        return b.decode("utf-8")
    except UnicodeDecodeError:
        return b.decode("latin-1", errors="ignore") # allows everything

def detect_filetype(input_path: Path):
    if globalVar.filetype:
        return globalVar.filetype

    # Read once
    input_bytes = input_path.read_bytes()
    text = decode_bytes(input_bytes).strip()

    # Check JSON (only accept dicts or lists)
    if text and text[0] in ('{', '['):
        try:
            parsed = json.loads(text)
            if isinstance(parsed, (dict, list)):
                globalVar.filetype = 'json'
                print(f"File type detected: {globalVar.filetype}")
                return globalVar.filetype
        except Exception:
            pass

    # Check CSV
    try:
        with open(input_path, 'r', newline='', encoding='utf-8', errors='ignore') as f:
            sample = f.read(1024)
            if '\n' in sample and ',' in sample:  # must have multiple lines to be plausible CSV
                csv.Sniffer().sniff(sample)
                globalVar.filetype = 'csv'
                print(f"File type detected: {globalVar.filetype}")
                return globalVar.filetype
    except Exception:
        pass

    # Check XML
    if text.startswith('<'):
        try:
            etree.fromstring(text.encode())
            globalVar.filetype = 'xml'
            print(f"File type detected: {globalVar.filetype}")
            return globalVar.filetype
        except Exception:
            pass

    if input_bytes.startswith(b"\xff\xd8\xff"):
        globalVar.filetype = 'jpg'
        print(f"File type detected: {globalVar.filetype}")
        return globalVar.filetype
    
    if input_bytes.startswith(b"\x7fELF"):
        globalVar.filetype = 'elf'
        print(f"File type detected: {globalVar.filetype}")
        return globalVar.filetype
    
    if input_bytes.startswith(b"%PDF-"):
        globalVar.filetype = 'pdf'
        print(f"File type detected: {globalVar.filetype}")
        return globalVar.filetype


    # Default to plaintext
    globalVar.filetype = 'plaintext'
    print(f"Defaulting: {globalVar.filetype}")
    return globalVar.filetype

def csv_to_rows(csv_text: str) -> list[list[str]]:
    f = StringIO(csv_text)
    reader = csv.reader(f)
    return [row for row in reader]

def rows_to_csv(rows: list[list[str]]) -> str:
    f = StringIO()
    writer = csv.writer(f, lineterminator='\n', escapechar='\\')
    writer.writerows(rows)
    return f.getvalue()

def json_parser(text: str) -> str:
    json_dict = flatten(json.loads(text), reducer="dot")
    mutated = json_mutate(json_dict)
    return json.dumps(unflatten(mutated, splitter="dot"))

def csv_parser(text: str) -> str:
    """Parse CSV text → mutate structured rows → return mutated CSV string."""
    # convert into 2d array
    try:
        rows = csv_to_rows(text)
    except Exception:
        rows = [[text]]

    # mutate
    mutated_rows = csv_mutate(rows)

    # convert to str
    mutated_csv_text = rows_to_csv(mutated_rows)

    #with open('output.bin', 'ab') as f: f.write(f'======New Output======\n{mutated_csv_text}\n'.encode())

    return mutated_csv_text

def plaintext_parser(input: list[str]) -> str:
    return agnostic_mutator.plaintext_mutate(input)

def xml_parser(input: str) -> str:
    tree = etree.fromstring(input.encode())
    mutated = xml_mutate(tree)
    return (etree.tostring(mutated).decode())

def parser(input_path: Path, file_content: bytes, seed: int) -> bytes:
    ft = detect_filetype(input_path)

    # Modify inputs to the functions as desired.
    match ft:
        case "csv":
            text = file_content.decode(errors='ignore')
            return (csv_parser(text)).encode()
        case "json":
            parts = file_content.decode(errors='ignore')
            return (json_parser(parts) + '\n').encode()
        case "jpg":
            # try:
            return jpg_mutate(file_content)
            # except Exception as e:
                # print(f"{Colours.BOLD}{Colours.RED} Exception in jpg_mutate: `{e}` {Colours.RESET}")
                # return file_content
        case "elf":
            try:
                return elf_mutate(file_content, seed)
            except Exception as e:
                print(f"{Colours.BOLD}{Colours.RED} Exception in elf_mutate: `{e}` {Colours.RESET}")
                return file_content
        case "pdf":
            try:
                return pdf_mutate(file_content)
            except Exception as e:
                print(f"{Colours.BOLD}{Colours.RED} Exception in pdf_mutate: `{e}` {Colours.RESET}")
                return file_content
        case "xml":
            parts = file_content.decode(errors='ignore')
            return (xml_parser(parts) + '\n').encode()
        case _:
            # assume plaintext if no match
            parts = file_content.decode(errors='ignore')
            return plaintext_parser(parts) + b'\n'
